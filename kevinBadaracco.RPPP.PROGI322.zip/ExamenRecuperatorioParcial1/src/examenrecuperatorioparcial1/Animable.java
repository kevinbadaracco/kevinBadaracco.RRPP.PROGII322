
package examenrecuperatorioparcial1;

public interface Animable {
    void animarPublico();
}
