
package examenrecuperatorioparcial1;

public class Banda extends Presentacion implements TocadorEnVivo {
    
    private int cantidadIntegrantesMax;
    
    public Banda(String nombre, String escenario, TipoDeEscenario tipoEscenario, int cantidadIntegrantesMax) {
        super(nombre, escenario, tipoEscenario);
        this.cantidadIntegrantesMax = cantidadIntegrantesMax;
    }

    @Override
    public void tocarEnVivo() {
        System.out.printf("La banda %s esta tocando en vivo!!", getNombre(), cantidadIntegrantesMax);
    }

    @Override 
    public String toString() {
        return "Banda(" + super.toString() + " | Cant de Integrantes max.= " + cantidadIntegrantesMax + ")";
    }
}