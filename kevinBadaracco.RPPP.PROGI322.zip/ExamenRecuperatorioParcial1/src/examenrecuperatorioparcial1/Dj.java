
package examenrecuperatorioparcial1;

public class Dj extends Presentacion implements Animable {
    
    private String estiloMusical;

    public Dj(String nombre, String escenario, TipoDeEscenario tipoEscenario, String estiloMusical) {
        super(nombre, escenario, tipoEscenario);
        this.estiloMusical = estiloMusical;
    }

    @Override
    public void animarPublico() {
        System.out.printf("El DJ %s esta poniendo musica de %s para animar al publico!!!", 
                          getNombre(), estiloMusical);
    }

    @Override 
    public String toString() {
        return "Dj(" + super.toString() + " | Estilo Musical= " + estiloMusical + ")";
    }
}
