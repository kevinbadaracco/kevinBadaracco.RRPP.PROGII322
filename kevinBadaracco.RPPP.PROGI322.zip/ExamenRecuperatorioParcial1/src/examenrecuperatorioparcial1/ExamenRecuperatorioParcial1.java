
package examenrecuperatorioparcial1;

public class ExamenRecuperatorioParcial1 {
    public static void main(String[] args) {
        Recital recital = new Recital("Mega Festival Estelar");

        System.out.println(">>> 1. AGREGAR PRESENTACIONES <<<");
        try {
            Banda banda1 = new Banda("Los Relámpagos", "Escenario Principal", TipoDeEscenario.EXTERIOR, 5);
            recital.agregarPresentacion(banda1);

            Solista solista1 = new Solista("Mia Coral", "Escenario Acústico", TipoDeEscenario.INTERIOR, "Guitarra");
            recital.agregarPresentacion(solista1);

            Dj dj1 = new Dj("BeatMaster Flex", "Carpa Techno", TipoDeEscenario.INTERIOR, "Techno");
            recital.agregarPresentacion(dj1);

            Banda banda2 = new Banda("Los Relámpagos", "Escenario Lateral", TipoDeEscenario.EXTERIOR, 4);
            recital.agregarPresentacion(banda2);

            System.out.println("\n[PRUEBA EXCEPCIÓN] Intentando agregar 'Los Relámpagos' en 'Escenario Principal' nuevamente:");
            Banda bandaDuplicada = new Banda("Los Relámpagos", "Escenario Principal", TipoDeEscenario.EXTERIOR, 6);
            recital.agregarPresentacion(bandaDuplicada);

        } catch (PresentacionDuplicadaException e) {
            System.err.println(e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }

        // 2. Mostrar presentaciones registradas
        recital.mostrarPresentaciones();

        // 3. Show en vivo y animar al publico
        
        // 4. Filtrar por tipo de escenario
        System.out.println("\n>>> 4. FILTRAR POR TIPO DE ESCENARIO <<<");
        recital.filtrarPorTipoEscenario(TipoDeEscenario.INTERIOR);
        recital.filtrarPorTipoEscenario(TipoDeEscenario.EXTERIOR);

        // 5. Eliminar presentaciones por tipo
        System.out.println("\n>>> 5. ELIMINAR PRESENTACIONES POR TIPO <<<");
        recital.eliminarPresentacionesPorTipo("Banda");
        
        recital.mostrarPresentaciones();
        
        recital.eliminarPresentacionesPorTipo("Solista");
        
        recital.mostrarPresentaciones();
    }
}
