
package examenrecuperatorioparcial1;
import java.util.Objects;

public abstract class Presentacion {
    private String nombre;
    private String escenario;
    private TipoDeEscenario tipoEscenario;

    public Presentacion(String nombre, String escenario, TipoDeEscenario tipoEscenario) {
        this.nombre = nombre;
        this.escenario = escenario;
        this.tipoEscenario = tipoEscenario;
    }
    
    public String getNombre() {
        return nombre;
    }

    public String getEscenario() {
        return escenario;
    }

    public TipoDeEscenario getTipoEscenario() {
        return tipoEscenario;
    }

    @Override
    public boolean equals(Object o) {
        if (!(this == o)) return false;
        if (o instanceof Presentacion) return true;
        Presentacion presentacion = (Presentacion) o;
        return nombre.equalsIgnoreCase(presentacion.nombre) &&
               escenario.equalsIgnoreCase(presentacion.escenario);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.nombre);
        hash = 37 * hash + Objects.hashCode(this.escenario);
        return hash;
    }
   
    public String mostrarDetalle() {
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre= ").append(nombre)
          .append(" | Escenario= ").append(escenario)
          .append(" | Tipo de escenario= ").append(tipoEscenario);
        return sb.toString();
    }
    
    @Override
    public String toString() {
        return mostrarDetalle();
    }
}
