package examenrecuperatorioparcial1;

public class PresentacionDuplicadaException extends Exception {
    private static final String MSJ = "ERROR | Ya existe una presentación con el mismo nombre y escenario";
            
    public PresentacionDuplicadaException() {
        super(MSJ);
    }
    
    public PresentacionDuplicadaException(String msjPers) {
        super(msjPers);
    }
}
