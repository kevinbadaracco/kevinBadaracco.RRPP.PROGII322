
package examenrecuperatorioparcial1;

import java.util.ArrayList;

public class Recital {
    
    private String nombre;
    private ArrayList<Presentacion> presentaciones;
    
    public Recital(String nombre) {
        this.nombre = nombre;
        this.presentaciones = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void agregarPresentacion(Presentacion presentacion) throws PresentacionDuplicadaException {
        verificarPresentacion(presentacion);
        presentaciones.add(presentacion);
        System.out.printf("INFO | Presentacion %s agregada exitosamente al recital %s", presentacion.getNombre(), nombre);
    }
    
    private void verificarPresentacion(Presentacion p) throws PresentacionDuplicadaException {
        if (p == null) throw new IllegalArgumentException("ERROR | Presentacion inexistente");
        if (presentaciones.contains(p)) throw new PresentacionDuplicadaException();
    }
    
    public void mostrarPresentaciones() {
        System.out.println("(--- Listado de presentaciones del recital " + this.getNombre() + "---)");
        verificarCantidadDePresentacionesHechas(presentaciones, "INFO | No hay ninguna presentación en la lista para mostrar");
        mostrarPresentacionesIndividualmente(presentaciones);
        System.out.println("-----------------------------------------------------------------------");
    }

    private boolean verificarCantidadDePresentacionesHechas(ArrayList<Presentacion> presentaciones, String msj) {
        if (presentaciones.isEmpty()) {
            System.out.println(msj);
        }
        return presentaciones.isEmpty();
    }
    
    private void mostrarPresentacionesIndividualmente(ArrayList<Presentacion> presentaciones) {
        if (!(presentaciones.isEmpty())) {
            for (Presentacion p : presentaciones) {
                System.out.println(p);
            }
        }
    }

    public void tocarEnVivo() {
        System.out.println("(---Tipos de presentaciones tocando en vivo en el escenario del recital" + this.getNombre() + "---)");
        if (!(presentaciones.isEmpty())) {
            animarPublicoPorPresentacion();
        }
        else {
            System.out.println("INFO | No hay ninguna presentacion actualmente que puedan animar al publico en el escenario...");
        }
    }
    
    public void tocarEnVivoPorPresentacion() {
        for (Presentacion p: presentaciones) {
            if (p instanceof TocadorEnVivo) {
                ((TocadorEnVivo) p).tocarEnVivo();
            }
            else {
                System.out.printf("MUSICA EN VIVO NO DISPONIBLE | Las presentacion de tipo %s no pueden tocar en vivo...", p.getClass());
            }
        }
    }
    
    public void animarPublico() {
        System.out.println("(---Tipos de presentaciones animando al publico en el escenario " + this.getNombre() + "---)");
        if (!(presentaciones.isEmpty())) {
            animarPublicoPorPresentacion();
        }
        else {
            System.out.println("INFO | No hay ninguna presentacion actualmente que puedan animar al publico en el escenario...");
        }
    }
    
    private void animarPublicoPorPresentacion() {
        for (Presentacion p: presentaciones) {
            if (p instanceof Animable) {
                ((Animable) p).animarPublico();
            }
            else {
                System.out.printf("ANIMACION NO DISPONIBLE | Las presentacion de tipo %s no pueden animar al publico...", p.getClass());
            }
        }
    }
    
    public ArrayList<Presentacion> filtrarPorTipoEscenario(TipoDeEscenario tipoEscenario) {
        System.out.println("(---Filtrado de presentaciones segun el tipo de escenario" + tipoEscenario + "del recital " + getNombre() + " ---)");
        ArrayList<Presentacion> presentacionesFiltradas = new ArrayList<>();
        for (Presentacion p : presentaciones) {
            if (p.getTipoEscenario() == tipoEscenario) {
                presentacionesFiltradas.add(p);
            }
        }
        verificarCantidadDePresentacionesHechas(presentacionesFiltradas, "ERROR | No hay ninguna presentacion con el tipo de escenario " + tipoEscenario + " del recital para mostrar");
        mostrarPresentacionesIndividualmente(presentacionesFiltradas);
        System.out.println("-----------------------------------------------------------------------");
        return presentacionesFiltradas;
    }
    
    public void eliminarPresentacionesPorTipo(String tipoPresentacion) {
        System.out.println("(---Eliminacion de presentaciones segun el tipo de presentacion" + tipoPresentacion + "del recital " + getNombre() + " ---)");        
        ArrayList<Presentacion> presentacionesAConservar = new ArrayList<>();
        
        int totalOriginal = presentaciones.size();

        for (Presentacion p : presentaciones) {
            if (!p.getClass().getName().equals(tipoPresentacion)) {
                presentacionesAConservar.add(p);
            }
        }
        
        int presentacionesEliminadas = totalOriginal - presentacionesAConservar.size();
        
        this.presentaciones = presentacionesAConservar;

        if (presentacionesEliminadas > 0) {
            System.out.printf("ACTUALIZACIÓN EXITOSA | Se eliminaron %d presentaciones de tipo %s", presentacionesEliminadas, tipoPresentacion);
        } else {
            System.out.printf("INFO | No se encontraron presentaciones de tipo %s para eliminar", tipoPresentacion);
        }
        System.out.println("-----------------------------------------------------------------------");
    }
}   
    
    

    
