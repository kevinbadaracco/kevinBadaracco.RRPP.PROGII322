
package examenrecuperatorioparcial1;

public class Solista extends Presentacion implements TocadorEnVivo, Animable {
    
    private String instrumentoPrincipal;

    public Solista(String nombre, String escenario, TipoDeEscenario tipoEscenario, String instrumentoPrincipal) {
        super(nombre, escenario, tipoEscenario);
        this.instrumentoPrincipal = instrumentoPrincipal;
    }

    @Override
    public void tocarEnVivo() {
        System.out.printf("El solista %s esta tocando su %s en vivo en el escenario %s!!", getNombre(), instrumentoPrincipal, getEscenario());
    }

    @Override
    public void animarPublico() {
        System.out.printf("El solista %s esta animando al publico levantando las manos!!!", getNombre());
    }

    @Override 
    public String toString() {
        return "Solista(" + super.toString() + " | Instrumento Principal= " + instrumentoPrincipal + ")";
    }
}
