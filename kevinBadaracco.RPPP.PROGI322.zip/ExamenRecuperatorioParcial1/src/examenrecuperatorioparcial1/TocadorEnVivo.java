
package examenrecuperatorioparcial1;

public interface TocadorEnVivo {
    void tocarEnVivo();
}
